import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs/internal/Observable';
import { Router } from '@angular/router';
import { compilePipeFromMetadata } from '@angular/compiler';


@Injectable()
export class CommonService {

//   httpOptions = {
//   header: new HttpHeaders({ 'Content-Type': 'application/json' })
// };
header = new HttpHeaders({ 'Content-Type': 'application/json' }).set('Access-Control-Allow-Origin', '*');
header1 = new HttpHeaders().set('Access-Control-Allow-Origin', '*');
  
  url = "http://localhost:8090/jewel"
selectedFile:File =null;
  constructor(private httpClient: HttpClient,  private router: Router   )  { }
  
  uploadGoldProductJSON(body:any){
    var res=localStorage.getItem('ProdId');
    return this.httpClient.post<any>(this.url+'/gold/addGoldProduct', body,{headers:this.header});
  }
  // http://localhost:8090/jewel/goldCategories/createGoldCate

  uploadGoldCategoryJSON(body:any){
    var res=localStorage.getItem('categoryName');
    return this.httpClient.post<any>(this.url+'/goldCategories/createGoldCate', body,{headers:this.header});
  }
  //http://localhost:8090/jewel/s3/fileUpload
  imageUpload(image: File): Observable<Response> {
    const formData = new FormData();
    formData.append('file', image);
    return this.httpClient.post<any>(this.url+ '/s3/fileUpload',formData,{headers:this.header1});
  }
  getgoldcategories(){
    const body={
      "categoryName": localStorage.getItem('categoryName'),
  }
    return this.httpClient.get(this.url+'/goldCategories/getGoldCategories',{headers:this.header});
  }
  getdiamondcategories(){
    const body={
      "categoryName": localStorage.getItem('categoryName'),
  }
    return this.httpClient.get(this.url+'/diamondCategories/getDiamondCategories',{headers:this.header});
  }
  getplatinumcategories(){
    const body={
      "categoryName": localStorage.getItem('categoryName'),
  }
    return this.httpClient.get(this.url+'/category/getPlatCategories',{headers:this.header});
  }
  getsilvercategories(){
    const body={
      "categoryName": localStorage.getItem('categoryName'),
  }
    return this.httpClient.get(this.url+'/silverCategories/getSilverCategories',{headers:this.header});
  }
  uploadDiamondCategoryJSON(body:any){
    var res=localStorage.getItem('categoryName');
    return this.httpClient.post<any>(this.url+'/diamondCategories/createDiamondCate', body,{headers:this.header});
  }
  uploadPlatinumCategoryJSON(body:any){
    var res=localStorage.getItem('categoryName');
    return this.httpClient.post<any>(this.url+'/category/createPlatCate', body,{headers:this.header});
  }
  uploadSilverCategoryJSON(body:any){
    var res=localStorage.getItem('categoryName');
    return this.httpClient.post<any>(this.url+'/silverCategories/createsilverCate', body,{headers:this.header});
  }
  uploadCustomerJSON(body:any){
    var res=localStorage.getItem('customerName');
    return this.httpClient.post<any>(this.url+'/customers/addNew', body,{headers:this.header});
  }
}
