export interface Product
{
  "categoryId": 0,
  "price": 0,
  "productName": "string",
  "quantity": 0,
  "weightsInGram": 0
}