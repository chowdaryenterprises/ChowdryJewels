export interface Customer
{
    "address": "string",
    "costOfPurchase": 0,
    "customerName": "string",
    "dateOfPurchase": "2019-03-26 T0 5:57:58.404Z",
    "phoneNumber": "string"
}