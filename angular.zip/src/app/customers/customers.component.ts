import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from '../common.service';
import { Router } from '@angular/router';
import { Customer } from './customer.model';

@Component({
  selector: 'app-customers',
  templateUrl: './customers.component.html',
  styleUrls: ['./customers.component.css']
})
export class CustomersComponent implements OnInit {
  public show_dialog: boolean = false;
  public button_name: any = 'Add New Customer';
  customerForm: FormGroup;
  Cstr:Customer[];
  constructor(private fb: FormBuilder, private commonservice: CommonService, private router: Router) { }

  ngOnInit() {
    this.customersform();

  }

  customersform() {
    this.customerForm = this.fb.group({
      'address': ['', Validators],
      'costOfPurchase': ['', Validators],
      'customerName': ['', Validators],
      'dateOfPurchase': ['', Validators],
      'phoneNumber': ['', Validators],
    })
  }


  Customer() {

    console.log(this.customerForm.value);

    const body = {
      'address': this.customerForm.controls['address'].value,
      'costOfPurchase': this.customerForm.controls['costOfPurchase'].value,
      'customerName': this.customerForm.controls['customerName'].value,
      'dateOfPurchase': this.customerForm.controls['dateOfPurchase'].value,
      'phoneNumber': this.customerForm.controls['phoneNumber'].value
    };

    this.commonservice.uploadCustomerJSON(body).subscribe(data => {
      console.log(data);
      this.customerForm.reset();

   


    }, error => {
      console.log("product details creation failed ");
    })
  }


  toggle() {
    this.show_dialog = !this.show_dialog;

    // CHANGE THE TEXT OF THE BUTTON.
    if (this.show_dialog)
      this.button_name = "Add New Customer";
    else
      this.button_name = "Add New Customer";
  }
}
