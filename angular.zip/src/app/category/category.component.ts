import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CommonService } from '../common.service';
import { Category } from '../category.model';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.css']
})
export class CategoryComponent implements OnInit {
  public show_dialog : boolean = false;
  public show_dialog1 : boolean = false;
  public show_dialog2 : boolean = false;
  public show_dialog3 : boolean = false;
  public button_name : any='Add New Gold Category' ;
  public button_name1 : any='Add New Diamond Category' ;
  public button_name2 : any='Add New Platinum Category' ;
  public button_name3 : any='Add New Silver Category' ;
  categoryForm: FormGroup;
  cty: Category[];
  diamondcategoryForm: FormGroup;
  platinumcategoryForm:FormGroup;
  silvercategoryForm:FormGroup;
  constructor(private router: Router,private fb: FormBuilder,private commonservice: CommonService) { }

  ngOnInit() {
    this.categorysForm();
    this.diamondcategorysForm();
    this.platinumcategorysForm();
    this.silvercategorysForm();
  }
  categorysForm(){
    this.categoryForm=this.fb.group({
    'categoryName':['',Validators]
    })
  }
  diamondcategorysForm(){
    this.diamondcategoryForm=this.fb.group({
    'categoryName':['',Validators]
    })
  }
  platinumcategorysForm(){
    this.platinumcategoryForm=this.fb.group({
    'categoryName':['',Validators]
    })
  }
  silvercategorysForm(){
    this.silvercategoryForm=this.fb.group({
    'categoryName':['',Validators]
    })
  }
  
  Category(){
  console.log(this.categoryForm.value);
  console.log (this.categoryForm.controls['categoryName'].value);
  
  const body={
    'categoryName': this.categoryForm.controls['categoryName'].value
  };
  
   this.commonservice.uploadGoldCategoryJSON(body).subscribe(data => {
    console.log(data);
    this.categoryForm.reset();


  }, error => {
    console.log("New Category Creation Failed ");
  })
}

DiamondCategory(){
  console.log(this.diamondcategoryForm.value);
  console.log (this.diamondcategoryForm.controls['categoryName'].value);
  
  const body={
    'categoryName': this.diamondcategoryForm.controls['categoryName'].value
  };
  
   this.commonservice.uploadDiamondCategoryJSON(body).subscribe(data => {
    console.log(data);
    this.diamondcategoryForm.reset();


  }, error => {
    console.log("New Category Creation Failed ");
  })
}

PlatinumCategory(){
  console.log(this.platinumcategoryForm.value);
  console.log (this.platinumcategoryForm.controls['categoryName'].value);
  
  const body={
    'categoryName': this.platinumcategoryForm.controls['categoryName'].value
  };
  
   this.commonservice.uploadPlatinumCategoryJSON(body).subscribe(data => {
    console.log(data);
    this.platinumcategoryForm.reset();


  }, error => {
    console.log("New Category Creation Failed ");
  })
}

SilverCategory(){
  console.log(this.silvercategoryForm.value);
  console.log (this.silvercategoryForm.controls['categoryName'].value);
  
  const body={
    'categoryName': this.silvercategoryForm.controls['categoryName'].value
  };
  
   this.commonservice.uploadSilverCategoryJSON(body).subscribe(data => {
    console.log(data);
    this.silvercategoryForm.reset();


  }, error => {
    console.log("New Category Creation Failed ");
  })
}
  toggle() {
    this.show_dialog = !this.show_dialog;

    // CHANGE THE TEXT OF THE BUTTON.
    if(this.show_dialog) 
      this.button_name = "Add New Gold Category";
    else
      this.button_name = "Add New Gold Category";
  }
  toggle1() {
    this.show_dialog1 = !this.show_dialog1;

    // CHANGE THE TEXT OF THE BUTTON.
    if(this.show_dialog1) 
      this.button_name1 = "Add New Diamond Category";
    else
      this.button_name1 = "Add New Diamond Category";
  }
  toggle2() {
    this.show_dialog2 = !this.show_dialog2;

    // CHANGE THE TEXT OF THE BUTTON.
    if(this.show_dialog2) 
      this.button_name2 = "Add New Platinum Category";
    else
      this.button_name2 = "Add New Platinum Category";
  }
  toggle3() {
    this.show_dialog3 = !this.show_dialog3;

    // CHANGE THE TEXT OF THE BUTTON.
    if(this.show_dialog3) 
      this.button_name3 = "Add New Silver Category";
    else
      this.button_name3 = "Add New Silver Category";
  }

}
