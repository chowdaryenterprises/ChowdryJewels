import { CommonService } from './../common.service';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  getgoldcategories: any;
  public goldCategories:any;


  constructor(private router: Router, private commonservice: CommonService) { }

  ngOnInit() {
  }
  btnClick4() {
    this.commonservice.getgoldcategories().subscribe(data => {
    console.log(data);

    }, error => {
      console.log("get gold categories failed")
    })
  }
  btnClick1() {
    this.commonservice.getdiamondcategories().subscribe(data => {
    console.log(data);

    }, error => {
      console.log("get gold categories failed")
    })
  }
  btnClick2() {
    this.commonservice.getplatinumcategories().subscribe(data => {
    console.log(data);

    }, error => {
      console.log("get gold categories failed")
    })
  }
  btnClick0() {
    this.commonservice.getsilvercategories().subscribe(data => {
    console.log(data);

    }, error => {
      console.log("get gold categories failed")
    })
  }
  btnClick() {
    this.router.navigate(['./products']);
  }
  CTC() {
    this.router.navigate(['./category']);
  }
  login(){
    this.router.navigate(['./login']);
  }
  CTCC(){
    this.router.navigate(['./customers']);
  }
}
