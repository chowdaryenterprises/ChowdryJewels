import { Component, OnInit } from '@angular/core';
import {FormGroup, FormControl, Validators, FormBuilder, FormArray}  from '@angular/forms';
import { CommonService } from '../common.service';
import { Product } from '../product.model';
import { Router } from '@angular/router';
class ImageSnippet {
  pending: boolean = false;
  status: string = 'init';
  constructor(public src: string, public file: File) {}
}
@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrls: ['./products.component.css']
})
export class ProductsComponent implements OnInit {

  public show_dialog : boolean = false;
  public show_dialog1 : boolean = false;
  public button_name : any = 'Add Gold Product';
  public button_name1 : any = 'Add Diamond Product';
  productForm: FormGroup;
  diamondForm: FormGroup;
  platinumForm: FormGroup;
  silverForm: FormGroup;
  prdlist: Product[];
  file: any;
  selectedFile: ImageSnippet;
  url: string | ArrayBuffer;
  constructor(private fb: FormBuilder,private commonservice: CommonService,private router: Router) { }

  ngOnInit() {
 this.productsform();

  }

productsform(){
  this.productForm=this.fb.group({
    'imagename':['',Validators],
    'categoryId':['',Validators],
    'price':['',Validators],
    'productName':['',Validators],
    'quantity':['',Validators],
    'weightsInGram':['',Validators],
    'url':['',Validators]
    
  })
}


Product(){
  
  console.log(this.productForm.value);
  console.log (this.productForm.controls['categoryId'].value);
  
  const body={
    'categoryId': this.productForm.controls['categoryId'].value,
    'price': this.productForm.controls['price'].value,
    'productName': this.productForm.controls['productName'].value,
    'quantity': this.productForm.controls['quantity'].value,
    'weightsInGram': this.productForm.controls['weightsInGram'].value,
    'imagename': this.productForm.controls['imagename'].value,
    'url': this.productForm.controls['url'].value,
    
    
    
  };
  
   this.commonservice.uploadGoldProductJSON(body).subscribe(data => {
    console.log(data);
    this.productForm.reset();
  }, error => {
    
  });
  this.commonservice.imageUpload(this.selectedFile.file).subscribe(data => {
    console.log(data);
    this.productForm.reset();
  },error =>{
    console.log("image upload failed");
  })
}

Diamond(){
  console.log(this.diamondForm.value);
  console.log(this.diamondForm.controls['categoryId']);

  const body={
    'categoryId':this.diamondForm.controls['categoryId'].value,
    'price':this.diamondForm.controls['price'].value,
    'productName':this.diamondForm.controls['productName'].value,
    'quantity':this.diamondForm.controls['quantity'].value,
    'weightsingram':this.diamondForm.controls['weightsingram'].value
  }
}

  toggle() {
    this.show_dialog = !this.show_dialog;

    // CHANGE THE TEXT OF THE BUTTON.
    if(this.show_dialog) 
      this.button_name = "Add Gold Product";
    else
      this.button_name = "Add Gold Product";
  }
  toggle1() {
    this.show_dialog1 = !this.show_dialog1;

    // CHANGE THE TEXT OF THE BUTTON.
    if(this.show_dialog1) 
      this.button_name1 = "Add Diamond Product";
    else
      this.button_name1 = "Add Diamond Product";
  }
  
  processFile(imageInput: any) {
    const file: File = imageInput.files[0];
    const reader = new FileReader();

    reader.addEventListener('load', (event: any) => {

      this.selectedFile = new ImageSnippet(event.target.result[0], file);

      this.selectedFile.pending = true;
      this.url=reader.result;
    });

    reader.readAsDataURL(file);
    
  }
}